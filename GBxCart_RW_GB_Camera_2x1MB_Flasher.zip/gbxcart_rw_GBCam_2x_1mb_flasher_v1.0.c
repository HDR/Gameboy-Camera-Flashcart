/*
 GBxCart RW - GBCamera 2MB 2x 1MB Mode Flasher
 Version: 1.0
 Author: Alex from insideGadgets (www.insidegadgets.com)
 Created: 27/07/2020
 Last Modified: 27/07/2020
 License: GPL
 
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

#include "setup.h" // See defines, variables, constants, functions here

int main(int argc, char **argv) {
	
	printf("GBxCart RW GBCamera 2MB 2x 1MB Mode Flasher v1.30 by insideGadgets\n");
	printf("##################################################################\n");
	
	// Check arguments
	if (argc >= 2) {
		read_config();
		
		// Open COM port
		if (com_test_port() == 0) {
			printf("Device not connected and couldn't be auto detected. Please make sure the COM port isn't open elsewhere.\n");
			read_one_letter();
			return 1;
		}
		printf("Connected on COM port: %i\n", cport_nr+1);
		
		// Break out of any existing functions on ATmega
		set_mode('0');
		
		// Get cartridge mode - Gameboy or Gameboy Advance
		cartridgeMode = request_value(CART_MODE);
		
		// Get firmware version
		gbxcartFirmwareVersion = request_value(READ_FIRMWARE_VERSION);
		
		// Get PCB version
		gbxcartPcbVersion = request_value(READ_PCB_VERSION);
		xmas_wake_up();
		
		if (gbxcartPcbVersion == PCB_1_0) {
			printf("\nPCB v1.0 is not supported for this function.");
			read_one_letter();
			return 1;
		}
		
		if (gbxcartFirmwareVersion <= 8) {
			printf("Firmware R9 or higher is required for this functionality.\n");
			read_one_letter();
			return 1;
		}
		
		
		// Separate the file name
		char filenameOnly[100];
		char filename[254];
		strncpy(filename, argv[1], 253);
		
		char *token = strtok(filename, "\\");
		while (token != NULL) {
			strncpy(filenameOnly, token, 99);
			token = strtok(NULL, "\\");
		}
		
		printf("\n--- Write ROM to Flash Cart ---\n");
		printf("Cart selected: ");
		
		uint32_t readBytes = 0;
		long fileSize = 0;
		
		// Grab file size
		FILE *romFile = fopen(argv[1], "rb");
		if (romFile != NULL) {
			fseek(romFile, 0, SEEK_END);
			fileSize = ftell(romFile);
			fseek(romFile, 0, SEEK_SET);
		}
		else {
			printf("\n%s \nFile not found\n", argv[1]);
			read_one_letter();
			return 1;
		}
		
		printf("Please change the switch on the cart to B1 (Bank 1) or B2 (Bank 2)\n"\
				 "Writing to Bank 1 will erase the whole chip.\n"\
				 "Please enter which 1MB bank number we should write to - 1 or 2\n"\
				 ">");
		char bankString[5];
		fgets(bankString, 5, stdin);
		int bankNumber = atoi(bankString);
		
		
		printf("\nGoing to write to ROM (Flash cart) from %s\n", filenameOnly);
		
		// PCB v1.3 - Set 5V
		if (gbxcartPcbVersion == PCB_1_3 || gbxcartPcbVersion == GBXMAS) {
			set_mode(VOLTAGE_5V);
			delay_ms(500);
		}
		
		// Check file size
		if (fileSize > 0x400000) {
			fclose(romFile);
			printf("\n%s \nFile size is larger than the available Flash cart space of 2 MByte\n", argv[1]);
			read_one_letter();
			return 1;
		}
		
		currAddr = 0x0000;
		endAddr = 0x7FFF;
		
		// Calculate banks needed from ROM file size
		romBanks = fileSize / 16384;
		
		// Flash Setup
		set_mode(GB_CART_MODE); // Gameboy mode
		gb_flash_pin_setup(WE_AS_WR_PIN); // Audio pin
		gb_flash_program_setup(GB_FLASH_PROGRAM_555);// Flash program byte method
		gb_check_change_flash_id(GB_FLASH_PROGRAM_555);
		
		// Chip erase
		if (bankNumber == 1) {
			printf("\nErasing Flash");
			xmas_chip_erase_animation();
			gb_flash_write_address_byte(0x555, 0xAA);
			gb_flash_write_address_byte(0x2AA, 0x55);
			gb_flash_write_address_byte(0x555, 0x80);
			gb_flash_write_address_byte(0x555, 0xAA);
			gb_flash_write_address_byte(0x2AA, 0x55);
			gb_flash_write_address_byte(0x555, 0x10);
			
			// Wait for first byte to be 0xFF
			wait_for_flash_chip_erase_ff(1);
			xmas_setup((romBanks * 16384) / 28);
		}
		
		printf("\n\nWriting to ROM (Flash cart) from %s\n", filenameOnly);
		printf("[             25%%             50%%             75%%            100%%]\n[");
		
		// Write ROM
		currAddr = 0x0000;
		for (uint16_t bank = 1; bank < romBanks; bank++) {				
			if (bank > 1) { currAddr = 0x4000; }
			
			// Set start address
			set_number(currAddr, SET_START_ADDRESS);
			delay_ms(5);
			
			// Read data
			while (currAddr < endAddr) {
				if (currAddr == 0x4000) { // Switch banks here just before the next bank, not any time sooner
					set_bank(0x2100, bank);
				}
				
				com_write_bytes_from_file(GB_FLASH_WRITE_64BYTE, romFile, 64);
				com_wait_for_ack();
				currAddr += 64;
				readBytes += 64;
				
				// Print progress
				print_progress_percent(readBytes, (romBanks * 16384) / 64);
				led_progress_percent(readBytes, (romBanks * 16384) / 28);
			}
		}
		
		printf("]");
		fclose(romFile);
	}
	
	printf("\n");
	xmas_idle_on();
	
	return 0;
}